// SAI Coin Demo
#include <iostream>
int main() { std::cout << "SAI Node Started"; return 0; }
