#!/bin/bash
g++ main.cpp -o saicoin
./saicoin
