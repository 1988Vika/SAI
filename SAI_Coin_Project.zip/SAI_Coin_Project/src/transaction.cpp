void dummy_transaction() {}
