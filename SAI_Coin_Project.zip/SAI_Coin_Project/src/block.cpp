void dummy_block() {}
