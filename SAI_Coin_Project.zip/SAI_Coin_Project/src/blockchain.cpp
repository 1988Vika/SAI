void dummy_blockchain() {}
