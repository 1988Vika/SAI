void dummy_blockchain();
