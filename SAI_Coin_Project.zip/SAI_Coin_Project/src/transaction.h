void dummy_transaction();
