void dummy_block();
