
#include <iostream>
int main() {
    std::cout << "SAI Coin Full Node Started." << std::endl;
    return 0;
}
